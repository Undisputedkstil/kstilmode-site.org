import { Challenge } from '../types';

export const CHALLENGES: Challenge[] = [
  {
    id: 'knowledge-mastery',
    title: 'Knowledge Mastery',
    pillar: 'knowledge',
    description: 'Sharpen your mind through daily reading, learning, and critical thinking exercises.',
    duration: 30,
    difficulty: 'intermediate',
    xpReward: 1500,
    tasks: [
      'Read 20 pages of a non-fiction book',
      'Summarize your key learnings',
      'Apply one concept you learned today',
      'Share knowledge with someone else',
    ],
  },
  {
    id: 'vitalflex-protocol',
    title: 'VitalFlex Protocol',
    pillar: 'strength',
    description: 'Build physical discipline and health through consistent exercise and nutrition.',
    duration: 30,
    difficulty: 'intermediate',
    xpReward: 1500,
    tasks: [
      'Complete 30 minutes of exercise',
      'Drink 3 liters of water',
      'Eat 3 nutritious meals',
      'Get 7-8 hours of quality sleep',
    ],
  },
  {
    id: 'mindbody-xp',
    title: 'MindBody XP',
    pillar: 'strength',
    description: 'An extreme challenge combining physical and mental discipline for extraordinary results.',
    duration: 60,
    difficulty: 'elite',
    xpReward: 3000,
    tasks: [
      'Complete two 45-minute workouts (2+ hours apart)',
      'Take a cold shower',
      'Meditate for 20 minutes',
      'Track all food intake',
      'No alcohol or processed foods',
    ],
    unlockLevel: 3,
  },
  {
    id: 'tenax-protocol',
    title: 'Tenax Protocol',
    pillar: 'tenacity',
    description: 'Develop grit and resilience through daily difficult tasks and discomfort.',
    duration: 21,
    difficulty: 'advanced',
    xpReward: 2000,
    tasks: [
      'Complete one difficult task before noon',
      'Practice 20 minutes of deep focus work',
      'Do something uncomfortable',
      'Journal about challenges faced',
      'No complaining all day',
    ],
  },
  {
    id: 'darkrise',
    title: 'DarkRise',
    pillar: 'inspiration',
    description: 'Unlock creative potential and inspiration through early rising and dedicated creation.',
    duration: 21,
    difficulty: 'advanced',
    xpReward: 2000,
    tasks: [
      'Wake up at 5:00 AM',
      'Create for one hour before any consumption',
      'Capture 3 ideas or observations',
      'Share one creation weekly',
    ],
    unlockLevel: 2,
  },
];

export const getChallenge = (id: string): Challenge | undefined => {
  return CHALLENGES.find(challenge => challenge.id === id);
};

export const getChallengesByPillar = (pillar: string): Challenge[] => {
  return CHALLENGES.filter(challenge => challenge.pillar === pillar);
};