import { PillarInfo } from '../types';
import { Brain, Dumbbell, Flame, Lightbulb, Building } from 'lucide-react';

export const PILLARS: Record<string, PillarInfo> = {
  knowledge: {
    id: 'knowledge',
    name: 'Knowledge',
    description: 'Sharpen your mind through elite learning and mental discipline',
    icon: 'Brain',
    color: '#3b82f6', // Blue
    hoverColor: '#2563eb',
    textColor: '#eff6ff',
    bgGradient: 'from-blue-600 to-blue-800',
  },
  strength: {
    id: 'strength',
    name: 'Strength',
    description: 'Build physical discipline, health, and consistency',
    icon: 'Dumbbell',
    color: '#ef4444', // Red
    hoverColor: '#dc2626',
    textColor: '#fef2f2',
    bgGradient: 'from-red-600 to-red-800',
  },
  tenacity: {
    id: 'tenacity',
    name: 'Tenacity',
    description: 'Develop grit, emotional toughness, and perseverance',
    icon: 'Flame',
    color: '#f97316', // Orange
    hoverColor: '#ea580c',
    textColor: '#fff7ed',
    bgGradient: 'from-orange-600 to-orange-800',
  },
  inspiration: {
    id: 'inspiration',
    name: 'Inspiration',
    description: 'Foster expression, clarity, identity, and creativity',
    icon: 'Lightbulb',
    color: '#8b5cf6', // Purple
    hoverColor: '#7c3aed',
    textColor: '#f5f3ff',
    bgGradient: 'from-purple-600 to-purple-800',
  },
  legacy: {
    id: 'legacy',
    name: 'Legacy',
    description: 'Build your vision, contribution, reputation, and memory',
    icon: 'Building',
    color: '#10b981', // Green
    hoverColor: '#059669',
    textColor: '#ecfdf5',
    bgGradient: 'from-green-600 to-green-800',
  },
};

export const getPillarIcon = (pillarId: string) => {
  switch (pillarId) {
    case 'knowledge':
      return Brain;
    case 'strength':
      return Dumbbell;
    case 'tenacity':
      return Flame;
    case 'inspiration':
      return Lightbulb;
    case 'legacy':
      return Building;
    default:
      return Brain;
  }
};