import { User } from '../types';

export const MOCK_USER: User = {
  id: 'user-001',
  name: 'Alex Warrior',
  email: 'alex@example.com',
  profileImage: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600',
  progress: {
    xp: 1250,
    level: 2,
    streak: 7,
    activeChallenges: ['knowledge-mastery'],
    completedChallenges: [],
    reflections: [
      {
        id: 'reflection-1',
        date: '2025-06-01',
        challengeId: 'knowledge-mastery',
        content: 'Today I learned about the concept of compound interest as it applies to knowledge and skills.',
        mood: 'good',
        learnings: 'Small daily improvements lead to massive results over time.',
        actions: 'Created a daily learning schedule to ensure consistent progress.',
      },
      {
        id: 'reflection-2',
        date: '2025-06-02',
        challengeId: 'knowledge-mastery',
        content: 'Studied cognitive biases and how they affect decision making.',
        mood: 'great',
        learnings: 'Awareness of biases helps make better decisions.',
        actions: 'Started journaling about decisions to identify potential biases.',
      },
    ],
  },
  joinDate: '2025-05-25',
  quote: 'The only limit to your impact is your imagination and commitment.',
  isPublic: true,
};