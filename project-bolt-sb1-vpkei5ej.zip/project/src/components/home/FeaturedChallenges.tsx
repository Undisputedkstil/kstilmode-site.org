import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CHALLENGES } from '../../data/challenges';
import { ChallengeCard } from '../ui/ChallengeCard';
import { Button } from '../ui/Button';

export const FeaturedChallenges: React.FC = () => {
  const navigate = useNavigate();
  const featuredChallenges = CHALLENGES.slice(0, 3); // Just show first 3 challenges
  
  return (
    <div className="py-24 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
            Featured <span className="text-blue-600 dark:text-blue-400">Challenges</span>
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-300">
            Begin your transformation with these popular challenges designed to push your limits
            and build consistent habits.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredChallenges.map((challenge) => (
            <ChallengeCard
              key={challenge.id}
              challenge={challenge}
              userLevel={2}
              onClick={() => navigate(`/challenges/${challenge.id}`)}
              className="group hover:transform hover:scale-[1.02] transition-all duration-300"
            />
          ))}
        </div>
        
        <div className="text-center">
          <Button 
            pillar="knowledge" 
            size="lg"
          >
            <Link to="/challenges" className="flex items-center">
              View All Challenges
              <span className="ml-2">→</span>
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
};