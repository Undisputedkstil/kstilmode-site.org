import React, { useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PillarInfo } from '../../types';
import { PILLARS } from '../../data/pillars';
import { PillarCard } from '../ui/PillarCard';

export const PillarSection: React.FC = () => {
  const navigate = useNavigate();
  const sectionRef = useRef<HTMLDivElement>(null);
  const pillarsArray = Object.values(PILLARS);
  
  // Handle scroll animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const cards = document.querySelectorAll('.pillar-card');
    cards.forEach((card) => observer.observe(card));

    return () => {
      cards.forEach((card) => observer.unobserve(card));
    };
  }, []);

  const handlePillarClick = (pillar: PillarInfo) => {
    navigate(`/pillar/${pillar.id}`);
  };

  return (
    <div
      ref={sectionRef}
      className="py-24 bg-gradient-to-b from-gray-100 to-white dark:from-gray-900 dark:to-gray-950"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
            The Five Pillars of <span className="text-blue-600 dark:text-blue-400">KstilMode</span>
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-300">
            Each pillar represents a core aspect of self-mastery. Together, they form the foundation
            of becoming your ultimate version.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
          {pillarsArray.map((pillar, index) => (
            <div
              key={pillar.id}
              className={`pillar-card opacity-0 transform translate-y-10 transition-all duration-700 ease-out delay-${
                index * 100
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <PillarCard
                pillar={pillar}
                onClick={() => handlePillarClick(pillar)}
                className="h-full cursor-pointer"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};