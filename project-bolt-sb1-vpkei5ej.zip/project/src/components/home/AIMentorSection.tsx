import React from 'react';
import { Brain, Sparkles, MessageSquare } from 'lucide-react';

export const AIMentorSection: React.FC = () => {
  return (
    <div className="py-24 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full mb-4">
            <Sparkles className="h-5 w-5 text-blue-600 dark:text-blue-400" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
            Meet <span className="text-blue-600 dark:text-blue-400">Zenith</span>, Your AI Mentor
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-300">
            A personalized AI coach that guides your self-mastery journey, providing insights, motivation, and adaptive challenges.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* AI Mentor Display */}
          <div className="lg:col-span-1 flex flex-col items-center justify-center">
            <div className="relative">
              <div className="w-48 h-48 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 shadow-xl flex items-center justify-center">
                <Brain className="h-24 w-24 text-white" />
              </div>
              <div className="absolute -bottom-2 -right-2 w-12 h-12 rounded-full bg-green-500 border-4 border-white dark:border-gray-950 flex items-center justify-center">
                <span className="text-white text-xs font-bold">LIVE</span>
              </div>
            </div>
            <h3 className="text-2xl font-bold mt-6 text-gray-900 dark:text-white">Zenith</h3>
            <p className="text-blue-600 dark:text-blue-400 font-medium">Elite AI Mentor</p>
          </div>
          
          {/* Chat Simulation */}
          <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-xl overflow-hidden">
            <div className="bg-blue-600 px-4 py-3 flex items-center">
              <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
              <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
              <h4 className="text-white font-medium ml-2">Zenith AI Chat</h4>
            </div>
            
            <div className="p-4 h-[300px] overflow-y-auto">
              {/* Message Bubbles */}
              <div className="flex mb-4">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mr-3 flex-shrink-0">
                  <Brain className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="bg-blue-100 dark:bg-blue-900/30 rounded-lg p-3 max-w-[80%]">
                  <p className="text-gray-800 dark:text-gray-200">
                    Good morning, Alex! Ready to continue your Knowledge Challenge today? You're on a 7-day streak. Keep it going! 💪
                  </p>
                </div>
              </div>
              
              <div className="flex justify-end mb-4">
                <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 max-w-[80%]">
                  <p className="text-gray-800 dark:text-gray-200">
                    Morning Zenith! Yes, I'm ready. What's my focus for today?
                  </p>
                </div>
              </div>
              
              <div className="flex mb-4">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mr-3 flex-shrink-0">
                  <Brain className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="bg-blue-100 dark:bg-blue-900/30 rounded-lg p-3 max-w-[80%]">
                  <p className="text-gray-800 dark:text-gray-200">
                    I've analyzed your progress and noticed you're excelling in critical thinking but could use more practice in applied learning. Today, focus on:
                  </p>
                  <ul className="list-disc pl-5 mt-2 text-gray-800 dark:text-gray-200">
                    <li>Read 20 pages on practical wisdom</li>
                    <li>Apply one concept from yesterday's reading</li>
                    <li>Write a 5-minute reflection on how you applied it</li>
                  </ul>
                  <p className="mt-2 text-gray-800 dark:text-gray-200">
                    This aligns perfectly with your Knowledge pillar goals. How does that sound?
                  </p>
                </div>
              </div>
              
              <div className="flex justify-end">
                <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 max-w-[80%]">
                  <p className="text-gray-800 dark:text-gray-200">
                    That's perfect! I'll get started right away.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Chat Input */}
            <div className="p-4 border-t border-gray-200 dark:border-gray-700 flex">
              <input 
                type="text" 
                placeholder="Type a message to Zenith..." 
                className="flex-grow bg-gray-100 dark:bg-gray-700 border-none rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-800 dark:text-gray-200"
                disabled
              />
              <button className="ml-2 p-2 bg-blue-600 text-white rounded-full disabled:opacity-50" disabled>
                <MessageSquare className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};