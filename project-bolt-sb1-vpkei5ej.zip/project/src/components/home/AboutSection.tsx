import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '../ui/Button';
import { Link } from 'react-router-dom';

export const AboutSection: React.FC = () => {
  return (
    <div className="py-24 bg-white dark:bg-gray-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900 dark:text-white">
              What is <span className="text-blue-600 dark:text-blue-400">KstilMode</span>?
            </h2>
            
            <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
              KstilMode is an immersive, gamified self-mastery system built to transform users into disciplined warriors 
              through structured challenges, learning paths, reflective journaling, and AI-powered mentorship.
            </p>
            
            <p className="text-lg text-gray-700 dark:text-gray-300 mb-8">
              Think of it as the gym for your mind and spirit — a lifestyle engineering system wrapped in the 
              experience of a video game, a mentor, and a legacy builder.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mt-1">
                  <ArrowRight className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                </div>
                <p className="ml-3 text-gray-600 dark:text-gray-400">
                  <strong className="text-gray-900 dark:text-white">Structured challenges</strong> to build discipline and consistency
                </p>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mt-1">
                  <ArrowRight className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                </div>
                <p className="ml-3 text-gray-600 dark:text-gray-400">
                  <strong className="text-gray-900 dark:text-white">Gamified system</strong> with XP, levels, and achievements
                </p>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mt-1">
                  <ArrowRight className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                </div>
                <p className="ml-3 text-gray-600 dark:text-gray-400">
                  <strong className="text-gray-900 dark:text-white">AI-powered mentorship</strong> to guide your journey
                </p>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mt-1">
                  <ArrowRight className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                </div>
                <p className="ml-3 text-gray-600 dark:text-gray-400">
                  <strong className="text-gray-900 dark:text-white">Community and accountability</strong> to stay motivated
                </p>
              </div>
            </div>
            
            <Button pillar="knowledge">
              <Link to="/about" className="flex items-center">
                Learn More
                <span className="ml-2">→</span>
              </Link>
            </Button>
          </div>
          
          {/* Image/Video Placeholder */}
          <div className="relative rounded-2xl overflow-hidden shadow-2xl">
            <div className="aspect-w-16 aspect-h-9 bg-gradient-to-br from-blue-900 to-blue-800 flex items-center justify-center">
              {/* This would be replaced with a real video in production */}
              <div className="text-center p-8">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4">
                  <div className="w-0 h-0 border-t-8 border-t-transparent border-l-12 border-l-white border-b-8 border-b-transparent ml-1"></div>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Explainer Video</h3>
                <p className="text-blue-100 max-w-md mx-auto">
                  Learn how KstilMode transforms your discipline, habits, and mindset in just 2 minutes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};