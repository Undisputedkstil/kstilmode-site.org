import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Brain, ChevronDown } from 'lucide-react';
import { Button } from '../ui/Button';

export const Hero: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    // Animation delay for the hero content
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div className="relative min-h-screen flex flex-col justify-center items-center bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950 overflow-hidden">
      {/* Animated Background Icon */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5">
        <Brain className="w-[800px] h-[800px] animate-pulse text-blue-600" />
      </div>
      
      {/* Animated Particle Effect */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div 
            key={i}
            className="absolute rounded-full bg-blue-500 opacity-10"
            style={{
              width: `${Math.random() * 10 + 5}px`,
              height: `${Math.random() * 10 + 5}px`,
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animation: `float ${Math.random() * 10 + 15}s linear infinite`
            }}
          />
        ))}
      </div>
      
      {/* Hero Content */}
      <div className={`
        max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8 z-10
        transition-all duration-1000 ease-out transform
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}
      `}>
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-gray-900 dark:text-white mb-6">
          <span className="block">Become Your</span>
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-blue-500 to-blue-700">
            Ultimate Version
          </span>
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-700 dark:text-gray-300 mb-10 max-w-3xl mx-auto">
          Think Sharp. Train Hard. Endure More. Inspire Loud. Leave a Legacy.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4 mb-16">
          <Button 
            pillar="knowledge" 
            size="lg"
            className="group"
          >
            <Link to="/challenges" className="flex items-center">
              Start Your Journey
              <span className="ml-2 group-hover:translate-x-1 transition-transform">→</span>
            </Link>
          </Button>
          
          <Button 
            pillar="knowledge" 
            variant="outline" 
            size="lg"
          >
            <Link to="/about">Learn More</Link>
          </Button>
        </div>
        
        {/* Animated Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all">
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
              250,000+
            </div>
            <div className="text-gray-600 dark:text-gray-300 text-sm font-medium">
              XP Earned by Users
            </div>
          </div>
          
          <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all">
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
              1,250+
            </div>
            <div className="text-gray-600 dark:text-gray-300 text-sm font-medium">
              Active Challengers
            </div>
          </div>
          
          <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all">
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
              5
            </div>
            <div className="text-gray-600 dark:text-gray-300 text-sm font-medium">
              Life-Changing Pillars
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className={`
        absolute bottom-8 left-1/2 transform -translate-x-1/2
        transition-all duration-1000 delay-500 ease-out
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}
      `}>
        <div className="flex flex-col items-center">
          <span className="text-sm text-gray-500 dark:text-gray-400 mb-2">Scroll to explore</span>
          <ChevronDown className="h-6 w-6 text-gray-500 dark:text-gray-400 animate-bounce" />
        </div>
      </div>
    </div>
  );
};