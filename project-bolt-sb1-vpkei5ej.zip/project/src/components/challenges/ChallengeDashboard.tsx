import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { CheckCircle2, Circle, CalendarDays, Brain, MessageSquare, BarChart3, Edit3 } from 'lucide-react';
import { getChallenge } from '../../data/challenges';
import { MOCK_USER } from '../../data/mockUser';
import { PILLARS, getPillarIcon } from '../../data/pillars';
import { Button } from '../ui/Button';

export const ChallengeDashboard: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const challenge = getChallenge(id || '');
  const [selectedTab, setSelectedTab] = useState('tasks');
  const [tasks, setTasks] = useState<string[]>(challenge?.tasks.map(() => '') || []);
  const [isChecklistComplete, setIsChecklistComplete] = useState(false);
  const [reflection, setReflection] = useState('');
  
  if (!challenge) {
    return <div>Challenge not found</div>;
  }
  
  const { title, description, pillar, tasks: challengeTasks } = challenge;
  const pillarData = PILLARS[pillar];
  const PillarIcon = getPillarIcon(pillar);
  
  const handleTaskChange = (index: number, completed: boolean) => {
    const newTasks = [...tasks];
    newTasks[index] = completed ? 'completed' : '';
    setTasks(newTasks);
    
    const allCompleted = newTasks.every(task => task === 'completed');
    setIsChecklistComplete(allCompleted);
  };
  
  const handleReflectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save the reflection to the database
    alert('Reflection submitted successfully!');
  };
  
  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const currentDay = 8; // For demo purposes
  
  return (
    <div className="min-h-screen pt-20 pb-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Challenge Header */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden mb-8">
          <div className={`h-2 w-full bg-gradient-to-r ${pillarData.bgGradient}`} />
          
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className={`p-2 rounded-full bg-${pillar}-100 dark:bg-${pillar}-900/30 mr-3`}>
                  <PillarIcon className={`w-6 h-6 text-${pillar}-600 dark:text-${pillar}-400`} />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{title}</h1>
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <CalendarDays className="h-4 w-4 mr-1" />
                    Day {currentDay} of {challenge.duration}
                  </div>
                </div>
              </div>
              
              <div className="hidden sm:flex items-center space-x-2">
                <div className={`
                  px-3 py-1 rounded-full
                  ${isChecklistComplete ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400'}
                `}>
                  {isChecklistComplete ? 'Day Completed' : 'In Progress'}
                </div>
                
                <div className="w-24 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-600 rounded-full"
                    style={{ width: `${(currentDay / challenge.duration) * 100}%` }}
                  ></div>
                </div>
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
                  {Math.round((currentDay / challenge.duration) * 100)}%
                </span>
              </div>
            </div>
            
            <p className="text-gray-600 dark:text-gray-300 mb-4">{description}</p>
            
            <div className="sm:hidden flex items-center justify-between mb-4">
              <div className={`
                px-3 py-1 rounded-full text-sm
                ${isChecklistComplete ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400'}
              `}>
                {isChecklistComplete ? 'Day Completed' : 'In Progress'}
              </div>
              
              <div className="flex items-center">
                <div className="w-24 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden mr-2">
                  <div 
                    className="h-full bg-blue-600 rounded-full"
                    style={{ width: `${(currentDay / challenge.duration) * 100}%` }}
                  ></div>
                </div>
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
                  {Math.round((currentDay / challenge.duration) * 100)}%
                </span>
              </div>
            </div>
            
            <div className="border-t border-gray-200 dark:border-gray-700 -mx-6 px-6 pt-4 mt-4">
              <nav className="flex space-x-4 overflow-x-auto">
                <button
                  onClick={() => setSelectedTab('tasks')}
                  className={`px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap ${
                    selectedTab === 'tasks' 
                      ? `bg-${pillar}-100 dark:bg-${pillar}-900/30 text-${pillar}-700 dark:text-${pillar}-300` 
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <CheckCircle2 className="h-4 w-4 inline mr-1" />
                  Today's Tasks
                </button>
                
                <button
                  onClick={() => setSelectedTab('reflection')}
                  className={`px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap ${
                    selectedTab === 'reflection' 
                      ? `bg-${pillar}-100 dark:bg-${pillar}-900/30 text-${pillar}-700 dark:text-${pillar}-300` 
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <Edit3 className="h-4 w-4 inline mr-1" />
                  Daily Reflection
                </button>
                
                <button
                  onClick={() => setSelectedTab('mentor')}
                  className={`px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap ${
                    selectedTab === 'mentor' 
                      ? `bg-${pillar}-100 dark:bg-${pillar}-900/30 text-${pillar}-700 dark:text-${pillar}-300` 
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <Brain className="h-4 w-4 inline mr-1" />
                  AI Mentor
                </button>
                
                <button
                  onClick={() => setSelectedTab('community')}
                  className={`px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap ${
                    selectedTab === 'community' 
                      ? `bg-${pillar}-100 dark:bg-${pillar}-900/30 text-${pillar}-700 dark:text-${pillar}-300` 
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <MessageSquare className="h-4 w-4 inline mr-1" />
                  Community
                </button>
                
                <button
                  onClick={() => setSelectedTab('progress')}
                  className={`px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap ${
                    selectedTab === 'progress' 
                      ? `bg-${pillar}-100 dark:bg-${pillar}-900/30 text-${pillar}-700 dark:text-${pillar}-300` 
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <BarChart3 className="h-4 w-4 inline mr-1" />
                  Progress
                </button>
              </nav>
            </div>
          </div>
        </div>
        
        {/* Tab Content */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
          {selectedTab === 'tasks' && (
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                  Today's Checklist
                </h2>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {currentDate}
                </div>
              </div>
              
              <div className="space-y-4 mb-8">
                {challengeTasks.map((task, index) => (
                  <div 
                    key={index} 
                    className={`
                      flex items-start p-4 rounded-lg transition-colors
                      ${tasks[index] === 'completed' 
                        ? `bg-${pillar}-50 dark:bg-${pillar}-900/10 border border-${pillar}-200 dark:border-${pillar}-800` 
                        : 'bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700'
                      }
                    `}
                  >
                    <button
                      onClick={() => handleTaskChange(index, tasks[index] !== 'completed')}
                      className="flex-shrink-0 mt-0.5 mr-3"
                    >
                      {tasks[index] === 'completed' ? (
                        <CheckCircle2 className={`h-5 w-5 text-${pillar}-600 dark:text-${pillar}-400`} />
                      ) : (
                        <Circle className="h-5 w-5 text-gray-400 dark:text-gray-500" />
                      )}
                    </button>
                    <div>
                      <p className={`font-medium ${
                        tasks[index] === 'completed' 
                          ? `text-${pillar}-800 dark:text-${pillar}-300` 
                          : 'text-gray-800 dark:text-gray-200'
                      }`}>
                        {task}
                      </p>
                      {tasks[index] === 'completed' && (
                        <p className={`text-sm text-${pillar}-600 dark:text-${pillar}-400 mt-1`}>
                          Completed
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              
              {isChecklistComplete ? (
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                  <div className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 mr-2 flex-shrink-0" />
                    <div>
                      <h3 className="font-medium text-green-800 dark:text-green-300 mb-1">All tasks completed for today!</h3>
                      <p className="text-green-700 dark:text-green-400 text-sm">
                        Great job! Now head over to the Reflection tab to journal about your experience today.
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                  <div className="flex items-start">
                    <Circle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 mt-0.5 mr-2 flex-shrink-0" />
                    <div>
                      <h3 className="font-medium text-yellow-800 dark:text-yellow-300 mb-1">Complete your daily checklist</h3>
                      <p className="text-yellow-700 dark:text-yellow-400 text-sm">
                        Check off each task as you complete them to maintain your streak and earn XP.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {selectedTab === 'reflection' && (
            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                Daily Reflection
              </h2>
              
              <form onSubmit={handleReflectionSubmit}>
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Today's Date
                  </label>
                  <input
                    type="text"
                    value={currentDate}
                    disabled
                    className="w-full px-4 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-gray-200"
                  />
                </div>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    How are you feeling about your progress today?
                  </label>
                  <select
                    className="w-full px-4 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-gray-200"
                  >
                    <option value="great">Great - I crushed it!</option>
                    <option value="good">Good - I'm making progress</option>
                    <option value="neutral">Neutral - Just another day</option>
                    <option value="challenging">Challenging - Had some struggles</option>
                    <option value="difficult">Difficult - Really struggled today</option>
                  </select>
                </div>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    What did you learn today?
                  </label>
                  <textarea
                    rows={3}
                    className="w-full px-4 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-gray-200"
                    placeholder="Share what you learned or discovered..."
                  ></textarea>
                </div>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Your reflection for today
                  </label>
                  <textarea
                    rows={6}
                    className="w-full px-4 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-gray-200"
                    placeholder="Write your thoughts, challenges, victories, and insights from today..."
                    value={reflection}
                    onChange={(e) => setReflection(e.target.value)}
                  ></textarea>
                </div>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    What actions will you take tomorrow based on today's experience?
                  </label>
                  <textarea
                    rows={3}
                    className="w-full px-4 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-gray-200"
                    placeholder="List your action items for tomorrow..."
                  ></textarea>
                </div>
                
                <div className="flex justify-end">
                  <Button 
                    pillar={pillar}
                    type="submit"
                    disabled={!reflection.trim()}
                  >
                    Save Reflection
                  </Button>
                </div>
              </form>
            </div>
          )}
          
          {selectedTab === 'mentor' && (
            <div className="p-6">
              <div className="flex items-center mb-6">
                <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center mr-3">
                  <Brain className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    Zenith AI Mentor
                  </h2>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Your personalized guide for the {title}
                  </p>
                </div>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-6 mb-6">
                <h3 className="font-bold text-gray-900 dark:text-white mb-3">
                  Today's Guidance
                </h3>
                
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Based on your progress in the {title}, I've prepared some specific advice to help you maximize your growth today:
                </p>
                
                <ul className="space-y-4">
                  <li className="flex">
                    <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 mr-3 text-sm font-bold">1</span>
                    <p className="text-gray-700 dark:text-gray-300">
                      <strong>Focus on consistency</strong> - Your streak is building nicely. Remember that even on difficult days, doing something small is better than breaking the chain.
                    </p>
                  </li>
                  
                  <li className="flex">
                    <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 mr-3 text-sm font-bold">2</span>
                    <p className="text-gray-700 dark:text-gray-300">
                      <strong>Deeper reflection</strong> - I've noticed your reflections focus on what you did, but less on how it impacted you. Try exploring your emotional and mental responses more.
                    </p>
                  </li>
                  
                  <li className="flex">
                    <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 mr-3 text-sm font-bold">3</span>
                    <p className="text-gray-700 dark:text-gray-300">
                      <strong>Resource recommendation</strong> - Based on your interests, I suggest checking out "Atomic Habits" by James Clear. It aligns perfectly with your current focus.
                    </p>
                  </li>
                </ul>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-6">
                <h3 className="font-bold text-gray-900 dark:text-white mb-3">
                  Ask Zenith
                </h3>
                
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Have a specific question about your challenge? Zenith can provide personalized guidance.
                </p>
                
                <div className="flex">
                  <input
                    type="text"
                    placeholder="Ask Zenith for advice or guidance..."
                    className="flex-grow px-4 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-l-lg text-gray-800 dark:text-gray-200"
                  />
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-r-lg font-medium transition-colors">
                    Ask
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {selectedTab === 'community' && (
            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                Community Chat
              </h2>
              
              <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-6 mb-6">
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Connect with others doing the {title} challenge. Share your experiences, ask questions, and support each other.
                </p>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="relative">
                      <span className="flex h-3 w-3 absolute -top-1 -right-1">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                      </span>
                      <div className="w-6 h-6 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center text-xs font-bold text-gray-700 dark:text-gray-300">
                        C
                      </div>
                    </div>
                    <div className="w-6 h-6 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center text-xs font-bold text-gray-700 dark:text-gray-300 -ml-1">
                      M
                    </div>
                    <div className="w-6 h-6 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center text-xs font-bold text-gray-700 dark:text-gray-300 -ml-1">
                      J
                    </div>
                    <div className="w-6 h-6 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center text-xs font-bold text-gray-700 dark:text-gray-300 -ml-1">
                      T
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400 ml-2">
                      24 active now
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <select className="text-sm bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md text-gray-800 dark:text-gray-200 px-2 py-1">
                      <option>Most Recent</option>
                      <option>Most Popular</option>
                      <option>Unanswered</option>
                    </select>
                  </div>
                </div>
                
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden mb-4">
                  <div className="max-h-96 overflow-y-auto p-4 space-y-4">
                    {/* Community messages would go here */}
                    <div className="flex">
                      <img 
                        src="https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1600" 
                        alt="User" 
                        className="w-8 h-8 rounded-full object-cover mr-3 flex-shrink-0"
                      />
                      <div>
                        <div className="flex items-baseline">
                          <span className="font-semibold text-gray-900 dark:text-white">Mark T.</span>
                          <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">2h ago</span>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 text-sm">
                          Day 8 complete! Finding it challenging to fit in reading time but made it work by waking up 30 minutes earlier. How's everyone else handling the time commitment?
                        </p>
                        <div className="flex mt-2 text-xs">
                          <button className="flex items-center text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905v.714L7.5 9h-3a2 2 0 00-2 2v.5" />
                            </svg>
                            Like (12)
                          </button>
                          <button className="flex items-center text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 ml-3">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                            </svg>
                            Reply (5)
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex">
                      <img 
                        src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1600" 
                        alt="User" 
                        className="w-8 h-8 rounded-full object-cover mr-3 flex-shrink-0"
                      />
                      <div>
                        <div className="flex items-baseline">
                          <span className="font-semibold text-gray-900 dark:text-white">Sara L.</span>
                          <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">4h ago</span>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 text-sm">
                          Just wanted to share a quick win - I've been using the Pomodoro technique (25 mins work, 5 mins break) to tackle the daily tasks, and it's been a game-changer for my focus!
                        </p>
                        <div className="flex mt-2 text-xs">
                          <button className="flex items-center text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905v.714L7.5 9h-3a2 2 0 00-2 2v.5" />
                            </svg>
                            Like (8)
                          </button>
                          <button className="flex items-center text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 ml-3">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                            </svg>
                            Reply (2)
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-200 dark:border-gray-700 p-3">
                    <div className="flex">
                      <input
                        type="text"
                        placeholder="Write a message..."
                        className="flex-grow px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-gray-200 text-sm"
                      />
                      <button className="ml-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors text-sm">
                        Send
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="text-center text-sm text-gray-500 dark:text-gray-400">
                  Share your journey with others! Posts are visible to all challenge participants.
                </div>
              </div>
            </div>
          )}
          
          {selectedTab === 'progress' && (
            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                Challenge Progress
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase mb-2">
                    Current Streak
                  </h3>
                  <div className="flex items-baseline">
                    <span className="text-3xl font-bold text-gray-900 dark:text-white">7</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">days</span>
                  </div>
                  <div className="mt-2 text-sm text-green-600 dark:text-green-400">
                    Personal best: 12 days
                  </div>
                </div>
                
                <div className="bg-white dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase mb-2">
                    XP Earned
                  </h3>
                  <div className="flex items-baseline">
                    <span className="text-3xl font-bold text-gray-900 dark:text-white">350</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">/ {challenge.xpReward}</span>
                  </div>
                  <div className="mt-2 text-sm text-blue-600 dark:text-blue-400">
                    23% of total possible XP
                  </div>
                </div>
                
                <div className="bg-white dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase mb-2">
                    Completion Rate
                  </h3>
                  <div className="flex items-baseline">
                    <span className="text-3xl font-bold text-gray-900 dark:text-white">92</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">%</span>
                  </div>
                  <div className="mt-2 text-sm text-green-600 dark:text-green-400">
                    Tasks completed on time
                  </div>
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700 p-4 mb-8">
                <h3 className="font-bold text-gray-900 dark:text-white mb-4">
                  Progress Timeline
                </h3>
                
                <div className="flex space-x-1 mb-2">
                  {Array.from({ length: 30 }, (_, i) => (
                    <div 
                      key={i} 
                      className={`flex-1 h-6 rounded-sm ${
                        i < currentDay 
                          ? (i % 2 === 0 ? `bg-${pillar}-500` : `bg-${pillar}-600`)
                          : 'bg-gray-200 dark:bg-gray-700'
                      }`}
                      title={`Day ${i + 1}`}
                    ></div>
                  ))}
                </div>
                
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                  <span>Day 1</span>
                  <span>Day 15</span>
                  <span>Day 30</span>
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
                <h3 className="font-bold text-gray-900 dark:text-white mb-4">
                  Task Completion Stats
                </h3>
                
                <div className="space-y-4">
                  {challengeTasks.map((task, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600 dark:text-gray-300 truncate pr-4" title={task}>
                          {task.length > 40 ? task.substring(0, 40) + '...' : task}
                        </span>
                        <span className="text-sm font-medium text-gray-900 dark:text-white">
                          {85 + Math.floor(Math.random() * 15)}%
                        </span>
                      </div>
                      <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                        <div 
                          className={`h-full bg-${pillar}-600`}
                          style={{ width: `${85 + Math.floor(Math.random() * 15)}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};