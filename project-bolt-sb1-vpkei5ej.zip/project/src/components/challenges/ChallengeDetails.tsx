import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, Trophy, AlertTriangle, CheckCircle2, Circle } from 'lucide-react';
import { Button } from '../ui/Button';
import { getChallenge } from '../../data/challenges';
import { PILLARS, getPillarIcon } from '../../data/pillars';

export const ChallengeDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const challenge = getChallenge(id || '');
  const [isJoined, setIsJoined] = useState(false);
  
  if (!challenge) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Challenge Not Found</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">The challenge you're looking for doesn't exist or has been removed.</p>
          <Link to="/challenges">
            <Button pillar="knowledge">Return to Challenges</Button>
          </Link>
        </div>
      </div>
    );
  }
  
  const { title, description, duration, difficulty, xpReward, tasks, pillar } = challenge;
  const pillarData = PILLARS[pillar];
  const PillarIcon = getPillarIcon(pillar);
  
  const joinChallenge = () => {
    setIsJoined(true);
    // In a real app, this would make an API call to join the challenge
  };
  
  return (
    <div className="min-h-screen pt-20 pb-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <Link to="/challenges" className="flex items-center text-blue-600 dark:text-blue-400 hover:underline">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Challenges
          </Link>
        </div>
        
        {/* Challenge Header */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden mb-8">
          <div className={`h-2 w-full bg-gradient-to-r ${pillarData.bgGradient}`} />
          
          <div className="p-6 sm:p-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6">
              <div className="flex items-center mb-4 sm:mb-0">
                <div className={`p-3 rounded-full bg-${pillar}-100 dark:bg-${pillar}-900/30 mr-4`}>
                  <PillarIcon className={`w-8 h-8 text-${pillar}-600 dark:text-${pillar}-400`} />
                </div>
                <div>
                  <span className={`text-sm font-semibold text-${pillar}-600 dark:text-${pillar}-400 uppercase tracking-wider`}>
                    {pillarData.name} Pillar
                  </span>
                  <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">{title}</h1>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <div className="flex items-center px-3 py-1 rounded-full bg-gray-100 dark:bg-gray-700">
                  <Calendar className="h-4 w-4 text-gray-500 dark:text-gray-400 mr-1" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {duration} Days
                  </span>
                </div>
                
                <div className="flex items-center px-3 py-1 rounded-full bg-yellow-100 dark:bg-yellow-900/20">
                  <Trophy className="h-4 w-4 text-yellow-600 dark:text-yellow-400 mr-1" />
                  <span className="text-sm font-medium text-yellow-700 dark:text-yellow-300">
                    {xpReward} XP
                  </span>
                </div>
              </div>
            </div>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg">
              {description}
            </p>
            
            {isJoined ? (
              <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 mb-6">
                <div className="flex items-start">
                  <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 mr-2 flex-shrink-0" />
                  <div>
                    <h3 className="font-medium text-green-800 dark:text-green-300 mb-1">You've joined this challenge!</h3>
                    <p className="text-green-700 dark:text-green-400 text-sm">
                      You can now track your progress and view your dashboard for this challenge.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <Button 
                pillar={pillar}
                size="lg"
                className="mb-6 w-full sm:w-auto"
                onClick={joinChallenge}
              >
                Join Challenge
              </Button>
            )}
            
            {isJoined && (
              <Link to={`/challenges/${id}/dashboard`}>
                <Button 
                  pillar={pillar}
                  variant="secondary"
                  size="lg"
                  className="mb-6 w-full sm:w-auto"
                >
                  Go to Challenge Dashboard
                </Button>
              </Link>
            )}
            
            {/* Challenge Details */}
            <div className="mt-8">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                Daily Tasks
              </h2>
              
              <div className="space-y-3">
                {tasks.map((task, index) => (
                  <div key={index} className="flex items-start bg-gray-50 dark:bg-gray-700/30 p-3 rounded-lg">
                    <Circle className="h-5 w-5 text-gray-400 dark:text-gray-500 mt-0.5 mr-3 flex-shrink-0" />
                    <p className="text-gray-700 dark:text-gray-300">{task}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mt-8">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                Challenge Structure
              </h2>
              
              <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">
                      Difficulty Level
                    </h3>
                    <p className={`text-lg font-medium ${
                      difficulty === 'beginner' ? 'text-green-600 dark:text-green-400' : 
                      difficulty === 'intermediate' ? 'text-blue-600 dark:text-blue-400' : 
                      difficulty === 'advanced' ? 'text-orange-600 dark:text-orange-400' : 
                      'text-red-600 dark:text-red-400'
                    }`}>
                      {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">
                      Total XP Reward
                    </h3>
                    <p className="text-lg font-medium text-yellow-600 dark:text-yellow-400">
                      {xpReward} XP
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">
                      Duration
                    </h3>
                    <p className="text-lg font-medium text-gray-700 dark:text-gray-300">
                      {duration} Days
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">
                      Daily Tasks
                    </h3>
                    <p className="text-lg font-medium text-gray-700 dark:text-gray-300">
                      {tasks.length} Tasks per Day
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};