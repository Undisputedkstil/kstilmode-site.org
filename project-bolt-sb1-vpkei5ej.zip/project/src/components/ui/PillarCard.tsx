import React from 'react';
import { PillarInfo } from '../../types';
import { getPillarIcon } from '../../data/pillars';

interface PillarCardProps {
  pillar: PillarInfo;
  onClick?: () => void;
  className?: string;
}

export const PillarCard: React.FC<PillarCardProps> = ({ 
  pillar, 
  onClick, 
  className = '' 
}) => {
  const Icon = getPillarIcon(pillar.id);
  
  return (
    <div 
      className={`
        rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300
        bg-gradient-to-br ${pillar.bgGradient} 
        transform hover:scale-[1.02] hover:-translate-y-1
        ${className}
      `}
      onClick={onClick}
    >
      <div className="p-6 flex flex-col items-center text-center">
        <div className={`p-3 rounded-full bg-white/10 backdrop-blur-sm mb-4`}>
          <Icon className={`w-10 h-10 text-${pillar.textColor}`} />
        </div>
        <h3 className={`text-xl font-bold mb-2 text-${pillar.textColor}`}>
          {pillar.name}
        </h3>
        <p className={`text-${pillar.textColor}/90 text-sm`}>
          {pillar.description}
        </p>
      </div>
    </div>
  );
};