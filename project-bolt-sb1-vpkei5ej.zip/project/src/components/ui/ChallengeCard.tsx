import React from 'react';
import { Challenge } from '../../types';
import { PILLARS, getPillarIcon } from '../../data/pillars';
import { Button } from './Button';

interface ChallengeCardProps {
  challenge: Challenge;
  onClick?: () => void;
  className?: string;
  userLevel?: number;
}

export const ChallengeCard: React.FC<ChallengeCardProps> = ({ 
  challenge,
  onClick,
  className = '',
  userLevel = 1
}) => {
  const { pillar, title, description, duration, difficulty, xpReward, unlockLevel } = challenge;
  const pillarData = PILLARS[pillar];
  const Icon = getPillarIcon(pillar);
  
  const isLocked = unlockLevel && userLevel < unlockLevel;
  
  return (
    <div className={`
      rounded-xl overflow-hidden shadow-lg relative 
      bg-white dark:bg-gray-800 
      transition-all duration-300 
      hover:shadow-xl 
      ${isLocked ? 'opacity-75 hover:opacity-90' : 'hover:scale-[1.02]'}
      ${className}
    `}>
      <div className={`h-2 w-full bg-gradient-to-r ${pillarData.bgGradient}`} />
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className={`flex items-center`}>
            <div className={`p-2 rounded-full bg-${pillar}-100 dark:bg-${pillar}-900/30 mr-3`}>
              <Icon className={`w-6 h-6 text-${pillar}-600 dark:text-${pillar}-400`} />
            </div>
            <div>
              <span className={`text-xs font-semibold text-${pillar}-600 dark:text-${pillar}-400 uppercase tracking-wider`}>
                {pillarData.name}
              </span>
              <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">{title}</h3>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <span className="text-xs font-medium px-2 py-1 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
              {duration} Days
            </span>
            <span className={`
              text-xs font-medium px-2 py-1 rounded-full 
              ${difficulty === 'beginner' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 
                difficulty === 'intermediate' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 
                difficulty === 'advanced' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400' : 
                'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'}
            `}>
              {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
            </span>
          </div>
        </div>
        
        <p className="text-gray-600 dark:text-gray-300 mb-6">{description}</p>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-yellow-500 mr-1">✨</span>
            <span className="text-sm font-semibold text-gray-700 dark:text-gray-200">
              {xpReward} XP
            </span>
          </div>
          
          <Button 
            pillar={pillar}
            variant="primary"
            size="sm"
            onClick={onClick}
            disabled={isLocked}
          >
            {isLocked ? `Unlock at Level ${unlockLevel}` : 'View Challenge'}
          </Button>
        </div>
      </div>
      
      {isLocked && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[1px]">
          <div className="bg-white/90 dark:bg-gray-800/90 p-4 rounded-lg shadow-lg text-center">
            <span className="text-2xl">🔒</span>
            <p className="font-bold text-gray-800 dark:text-gray-100">Locked</p>
            <p className="text-sm text-gray-600 dark:text-gray-300">Reach Level {unlockLevel} to unlock</p>
          </div>
        </div>
      )}
    </div>
  );
};