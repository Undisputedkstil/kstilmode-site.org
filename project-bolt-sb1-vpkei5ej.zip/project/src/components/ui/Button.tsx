import React from 'react';
import { Pillar } from '../../types';
import { PILLARS } from '../../data/pillars';

interface ButtonProps {
  children: React.ReactNode;
  pillar?: Pillar;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  pillar = 'knowledge',
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  onClick,
  disabled = false,
  className = '',
  icon,
}) => {
  const pillarData = PILLARS[pillar];
  
  const baseClasses = 'rounded-lg font-semibold inline-flex items-center justify-center transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2';
  
  const sizeClasses = {
    sm: 'py-1.5 px-3 text-sm',
    md: 'py-2 px-4 text-base',
    lg: 'py-3 px-6 text-lg',
  };
  
  const variantClasses = {
    primary: `bg-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-600 hover:bg-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-700 text-white shadow-md hover:shadow-lg focus:ring-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-500`,
    secondary: `bg-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-100 hover:bg-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-200 text-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-800 focus:ring-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-200`,
    outline: `border-2 border-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-600 bg-transparent hover:bg-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-50 text-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-700 focus:ring-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-300`,
    ghost: `bg-transparent hover:bg-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-50 text-${pillar === 'knowledge' ? 'blue' : pillar === 'strength' ? 'red' : pillar === 'tenacity' ? 'orange' : pillar === 'inspiration' ? 'purple' : 'green'}-700`,
  };
  
  const classes = `
    ${baseClasses}
    ${sizeClasses[size]}
    ${variantClasses[variant]}
    ${fullWidth ? 'w-full' : ''}
    ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
    ${className}
  `;

  return (
    <button 
      className={classes}
      onClick={onClick}
      disabled={disabled}
    >
      {icon && <span className="mr-2">{icon}</span>}
      {children}
    </button>
  );
};