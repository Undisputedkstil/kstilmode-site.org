import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Youtube, Brain } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Quote Banner */}
      <div className="bg-gradient-to-r from-blue-700 to-blue-900 py-12">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-xl md:text-2xl font-medium italic text-white mb-2">
            "Think Sharp. Train Hard. Endure More. Inspire Loud. Leave a Legacy."
          </p>
          <div className="h-1 w-24 bg-white/30 mx-auto my-4"></div>
          <p className="text-white/80">The KstilMode Way</p>
        </div>
      </div>
      
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          {/* Logo and Socials */}
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center mb-4">
              <div className="relative h-10 w-10 mr-2">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-blue-700 rounded-lg opacity-80"></div>
                <Brain className="h-6 w-6 absolute inset-0 m-auto text-white" />
              </div>
              <span className="font-bold text-xl text-white">
                KstilMode
              </span>
            </Link>
            <p className="text-gray-400 mb-4 max-w-md">
              KstilMode is a gamified self-mastery system designed to transform users into disciplined warriors through challenges, learning paths, journals, and mentorship.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          {/* Links Columns */}
          <div>
            <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase mb-4">
              Explore
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/challenges" className="text-gray-400 hover:text-white transition-colors">
                  Challenges
                </Link>
              </li>
              <li>
                <Link to="/development" className="text-gray-400 hover:text-white transition-colors">
                  Development Centre
                </Link>
              </li>
              <li>
                <Link to="/community" className="text-gray-400 hover:text-white transition-colors">
                  Community
                </Link>
              </li>
              <li>
                <Link to="/store" className="text-gray-400 hover:text-white transition-colors">
                  Store
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase mb-4">
              The 5 Pillars
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/pillar/knowledge" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Knowledge
                </Link>
              </li>
              <li>
                <Link to="/pillar/strength" className="text-gray-400 hover:text-red-400 transition-colors">
                  Strength
                </Link>
              </li>
              <li>
                <Link to="/pillar/tenacity" className="text-gray-400 hover:text-orange-400 transition-colors">
                  Tenacity
                </Link>
              </li>
              <li>
                <Link to="/pillar/inspiration" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Inspiration
                </Link>
              </li>
              <li>
                <Link to="/pillar/legacy" className="text-gray-400 hover:text-green-400 transition-colors">
                  Legacy
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase mb-4">
              Resources
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/blog" className="text-gray-400 hover:text-white transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-400 hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-white transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-white transition-colors">
                  About
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} KstilMode. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <Link to="/privacy" className="text-gray-400 hover:text-white text-sm transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-gray-400 hover:text-white text-sm transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};