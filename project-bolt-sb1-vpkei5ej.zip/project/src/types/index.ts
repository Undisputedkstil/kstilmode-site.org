export type Pillar = 'knowledge' | 'strength' | 'tenacity' | 'inspiration' | 'legacy';

export interface PillarInfo {
  id: Pillar;
  name: string;
  description: string;
  icon: string;
  color: string;
  hoverColor: string;
  textColor: string;
  bgGradient: string;
}

export interface Challenge {
  id: string;
  title: string;
  pillar: Pillar;
  description: string;
  duration: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'elite';
  xpReward: number;
  tasks: string[];
  unlockLevel?: number;
}

export interface UserProgress {
  xp: number;
  level: number;
  streak: number;
  activeChallenges: string[];
  completedChallenges: string[];
  reflections: Reflection[];
}

export interface Reflection {
  id: string;
  date: string;
  challengeId: string;
  content: string;
  mood: 'great' | 'good' | 'neutral' | 'challenging' | 'difficult';
  learnings: string;
  actions: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  profileImage?: string;
  progress: UserProgress;
  joinDate: string;
  quote?: string;
  isPublic: boolean;
}