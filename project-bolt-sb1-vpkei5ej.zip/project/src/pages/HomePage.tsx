import React from 'react';
import { Hero } from '../components/home/Hero';
import { PillarSection } from '../components/home/PillarSection';
import { FeaturedChallenges } from '../components/home/FeaturedChallenges';
import { AboutSection } from '../components/home/AboutSection';
import { AIMentorSection } from '../components/home/AIMentorSection';

export const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen">
      <Hero />
      <PillarSection />
      <FeaturedChallenges />
      <AboutSection />
      <AIMentorSection />
    </div>
  );
};